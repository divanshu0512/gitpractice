import React from 'react'

function Error() {
  return (
    <div>page not found</div>
  )
}

export default Error